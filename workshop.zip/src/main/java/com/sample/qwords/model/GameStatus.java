package com.sample.qwords.model;

public enum GameStatus {
    NOTSTARTED,
    INPROGRESS,
    SUCCESS,
    FAILED,
}
